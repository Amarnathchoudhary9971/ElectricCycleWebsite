// DASHBOARD INTERNAL SWITCHING SCRIPT
function switcher() {
  document.getElementById("acc").style.display = "none";
  document.getElementById("hc").style.display = "block";
}
function switcher2() {
  document.getElementById("hc").style.display = "none";
  document.getElementById("acc").style.display = "block";
}
